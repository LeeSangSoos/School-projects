package edu.skku.cs.pa2

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView


class GridAdapter (private val context: Context, private val cells: List<Int>, private var image: Drawable= ColorDrawable(
    Color.TRANSPARENT), private var turn:Float=0.0f, var size:Int=5, var user_pos:Int=0, var hintpos:Int=-1) : BaseAdapter(){
    override fun getCount(): Int {
        return cells.size
    }

    override fun getItem(p0: Int): Any {
        return cells.get(p0)
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val view:View=View.inflate(context,R.layout.maze_cell,null)

        var background=view.findViewById<ImageView>(R.id.background)
        var imageview=view.findViewById<ImageView>(R.id.character)
        val walltype=cells.get(p0)
        val layoutParams=background.layoutParams as ViewGroup.MarginLayoutParams
        val dp=context.resources.displayMetrics.density
        val dpasps=(350/size*dp).toInt()
        var marginsize=dpasps/30
        var upm=0
        var bottomm=0
        var rightm=0
        var leftm=0
        if(walltype and 1!=0 || p0%size==(size-1) || cells[p0+1] and 4!=0)
            rightm=marginsize
        if(walltype and 2!=0 || p0>=size*(size-1) || cells[p0+size] and 8!=0)
            bottomm=marginsize
        if(walltype and 4!=0 || p0%size==0 || cells[p0-1] and 1!=0)
            leftm=marginsize
        if(walltype and 8!=0 || p0<size || cells[p0-size] and 2!=0)
            upm=marginsize

        layoutParams.setMargins(leftm,upm,rightm,bottomm)

        layoutParams.width=dpasps+3
        layoutParams.height=dpasps
        if(rightm==marginsize)
            layoutParams.width-=marginsize
        if(leftm==marginsize)
            layoutParams.width-=marginsize
        if(upm==marginsize)
            layoutParams.height-=marginsize
        if(bottomm==marginsize)
            layoutParams.height-=marginsize
        background.layoutParams=layoutParams

        if(p0==user_pos){
            image=context.resources.getDrawable(R.drawable.user)
            imageview.rotation=turn
        }
        else if(p0==(size*size-1)){
            image=context.resources.getDrawable(R.drawable.goal)
        }
        else if(p0==hintpos){
            Log.i("r","in image")
            image=context.resources.getDrawable(R.drawable.hint)
        }
        else
            image= ColorDrawable(Color.TRANSPARENT)
        imageview.setImageDrawable(image)

        return view
    }

}