package edu.skku.cs.pa2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.GridView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

class MazeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maze)
        val mazename=intent.getStringExtra("Mazename")

        val client= OkHttpClient()
        val host = "http://121.169.12.99:10099/maze/map?name=$mazename"
        val req= Request.Builder().url(host).build()
        var info= listOf<Int>()
        var size:Int=0
        var userpos:Int=0
        var turn:Float=0f
        var turnT=0
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }
            override fun onResponse(call: Call, response: Response) {
                response.use{
                    if (!response.isSuccessful) throw IOException("Unexpected code $response")
                    val data = response.body!!.string()
                    val mazesource=Gson().fromJson(data, Mazeinfo::class.java)
                    val info1=mazesource.maze.split("\\s+".toRegex())
                    size=info1[0].toInt()
                    val info2 = info1.drop(1).dropLast(1)
                    info=info2.map{it.toInt()}
                    Log.i("Response","info: $info")

                    CoroutineScope(Dispatchers.Main).launch {
                        val gridAdapter=GridAdapter(this@MazeActivity, info,size=size)
                        var gridView=findViewById<GridView>(R.id.mazegrid)
                        gridView.numColumns=size
                        gridView.adapter=gridAdapter
                    }
                }
            }

        })

        val leftbtn=findViewById<Button>(R.id.leftbtn)
        val rightbtn=findViewById<Button>(R.id.rightbtn)
        val upbtn=findViewById<Button>(R.id.upbtn)
        val downbtn=findViewById<Button>(R.id.downbtn)
        val turntext=findViewById<TextView>(R.id.turntext)
        val hintbtn=findViewById<Button>(R.id.hintbtn)
        var hintused=0

        leftbtn.setOnClickListener{
            if(info[userpos] and 4==0 && userpos%size!=0 && userpos!=0){
                turn=270f
                userpos-=1
                turnT+=1
                turntext.setText("Turn : ${turnT.toString()}")
                val gridAdapter=GridAdapter(this@MazeActivity, info, user_pos = userpos, turn=turn ,size=size)
                var gridView=findViewById<GridView>(R.id.mazegrid)
                gridView.numColumns=size
                gridView.adapter=gridAdapter
                if(userpos==(size*size-1))
                    Toast.makeText(this@MazeActivity, "Finish!",Toast.LENGTH_SHORT).show()
            }
        }
        rightbtn.setOnClickListener{
            if(info[userpos] and 1==0 && (userpos+1)%size!=0){
                turn=90f
                userpos+=1
                turnT+=1
                turntext.setText("Turn : ${turnT.toString()}")
                val gridAdapter=GridAdapter(this@MazeActivity, info, user_pos = userpos, turn=turn ,size=size)
                var gridView=findViewById<GridView>(R.id.mazegrid)
                gridView.numColumns=size
                gridView.adapter=gridAdapter
                if(userpos==(size*size-1))
                    Toast.makeText(this@MazeActivity, "Finish!",Toast.LENGTH_SHORT).show()
            }
        }
        upbtn.setOnClickListener{
            if(info[userpos] and 8==0 && (userpos-size)>=0){
                turn=0f
                userpos-=size
                turnT+=1
                turntext.setText("Turn : ${turnT.toString()}")
                val gridAdapter=GridAdapter(this@MazeActivity, info, user_pos = userpos, turn=turn ,size=size)
                var gridView=findViewById<GridView>(R.id.mazegrid)
                gridView.numColumns=size
                gridView.adapter=gridAdapter
                if(userpos==(size*size-1))
                    Toast.makeText(this@MazeActivity, "Finish!",Toast.LENGTH_SHORT).show()
            }
        }
        downbtn.setOnClickListener{
            if(info[userpos] and 2==0 && (userpos+size)<(size*size)){
                turn=180f
                userpos+=size
                turnT+=1
                turntext.setText("Turn : ${turnT.toString()}")
                val gridAdapter=GridAdapter(this@MazeActivity, info, user_pos = userpos, turn=turn ,size=size)
                var gridView=findViewById<GridView>(R.id.mazegrid)
                gridView.numColumns=size
                gridView.adapter=gridAdapter
                if(userpos==(size*size-1))
                    Toast.makeText(this@MazeActivity, "Finish!",Toast.LENGTH_SHORT).show()
            }
        }
        hintbtn.setOnClickListener{
            if(hintused!=0){

            }
            else{
                hintused=1
                var tracker=size*size-1
                var visited= mutableListOf<Int>()
                var realvisited= mutableListOf<Int>()
                while(tracker!=(userpos)){
                    if(tracker !in realvisited)
                        realvisited.add(tracker)
                    var neighbor= mutableListOf<Int>()
                    if(info[tracker] and 4==0 && tracker%size!=0 && tracker!=0 && (tracker-1) !in realvisited){
                        neighbor.add(tracker-1)
                    }
                    if(info[tracker] and 1==0 && (tracker+1)%size!=0 && (tracker+1) !in realvisited){
                        neighbor.add(tracker+1)
                    }
                    if(info[tracker] and 8==0 && (tracker-size)>=0 && (tracker-size) !in realvisited){
                        neighbor.add(tracker-size)
                    }
                    if(info[tracker] and 2==0 && (tracker+size)<(size*size) && (tracker+size) !in realvisited){
                        neighbor.add(tracker+size)
                    }
                    if(neighbor.isEmpty() && visited.isNotEmpty()){
                        tracker=visited[(visited.size)-1]
                        visited.removeAt((visited.size)-1)
                    }
                    else{
                        if(neighbor[0]==userpos){
                            break
                        }
                        visited.add(tracker)
                        realvisited.add(tracker)
                        tracker=neighbor[0]
                    }
                }

                val gridAdapter=GridAdapter(this@MazeActivity, info, user_pos = userpos, turn=turn ,size=size, hintpos = tracker)
                var gridView=findViewById<GridView>(R.id.mazegrid)
                gridView.numColumns=size
                gridView.adapter=gridAdapter
            }
        }
    }
}