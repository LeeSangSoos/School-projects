package edu.skku.cs.pa2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import android.widget.TextView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException

class MazeSelectionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mazeselection)

        val username=intent.getStringExtra("Username")
        val username_textview=findViewById<TextView>(R.id.username)
        username_textview.setText(username)

        val client= OkHttpClient()
        val host = "http://121.169.12.99:10099/maps"
        val req=Request.Builder().url(host).build()
        client.newCall(req).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                e.printStackTrace()
            }
            override fun onResponse(call: Call, response: Response) {
                response.use{
                    if (!response.isSuccessful) throw IOException("Unexpected code $response")
                    val data = response.body!!.string()

                    val typeToken=object: TypeToken<List<MazeEntry>>() {}.type
                    val infolist= Gson().fromJson<List<MazeEntry>>(data, typeToken)

                    CoroutineScope(Dispatchers.Main).launch {
                        val listAdapter=MazelistAdapter(this@MazeSelectionActivity, infolist)
                        var listView=findViewById<ListView>(R.id.mazelistview)
                        listView.adapter=listAdapter
                    }
                }
            }

        })

    }
}