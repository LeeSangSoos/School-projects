package edu.skku.cs.pa2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

class SignInActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signin)

        val signinBtn=findViewById<Button>(R.id.button)
        val inputText=findViewById<EditText>(R.id.editTextText)

        val client=OkHttpClient()
        val host = "http://121.169.12.99:10099/users"

        signinBtn.setOnClickListener{
            val inputname=inputText.text.toString()
            val json= Gson().toJson(Users(inputname))
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val req = Request.Builder().url(host).post(json.toString().toRequestBody(mediaType)).build()
            client.newCall(req).enqueue(object : Callback{
                override fun onFailure(call: Call, e: IOException) {
                    e.printStackTrace()
                }
                override fun onResponse(call: Call, response: Response) {
                    response.use{
                        if (!response.isSuccessful) throw IOException("Unexpected code $response")
                        val str = response.body!!.string()
                        val data = Gson().fromJson(str, Success::class.java)
                        if(data.success == true){
                            val intent= Intent(this@SignInActivity, MazeSelectionActivity::class.java)
                            intent.putExtra("Username",inputname)
                            startActivity(intent)
                        }
                        else{
                            runOnUiThread{
                                Toast.makeText(this@SignInActivity, "Wrong User Name", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            })
        }
    }
}