package edu.skku.cs.pa2

import android.content.Context
import android.content.Intent
import android.os.Parcel
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity

class MazelistAdapter(private val context: Context, private val entries: List<MazeEntry>) : BaseAdapter(){
    override fun getCount(): Int {
        return entries.size
    }

    override fun getItem(p0: Int): Any {
        return entries.get(p0)
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val inflater:LayoutInflater=
            LayoutInflater.from(context)
        val view:View=inflater.inflate(R.layout.maze_entry,null)

        var mazename=view.findViewById<TextView>(R.id.mazename)
        var mazesize=view.findViewById<TextView>(R.id.mazesize)
        var mazestart=view.findViewById<Button>(R.id.startbtn)

        mazename.setText(entries.get(p0).name)
        mazesize.setText(entries.get(p0).size)
        mazestart.setOnClickListener{
            val intent= Intent(context, MazeActivity::class.java)
            intent.putExtra("Mazename",entries.get(p0).name)
            context.startActivity(intent)
        }

        return view
    }

}