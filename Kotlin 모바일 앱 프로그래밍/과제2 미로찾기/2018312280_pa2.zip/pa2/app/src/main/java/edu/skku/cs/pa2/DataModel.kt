package edu.skku.cs.pa2

data class Users(var username: String ?= null)
data class Success(var success: Boolean ?= null)
data class MazeEntry(val name: String, val size: String)
data class Mazeinfo(val maze: String)