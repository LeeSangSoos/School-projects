package edu.skku.cs.pa1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import androidx.recyclerview.widget.RecyclerView


class main_adapter (val data: ArrayList<String>, val context: Context, val answer: String): BaseAdapter() {
    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(p0: Int): Any {
        return data[p0]
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val generatedView=inflater.inflate(R.layout.main_words, null)
        val letadapter=generatedView.findViewById<RecyclerView>(R.id.listview1)
        val wordAdapter=word_adapter(data[p0],answer)
        letadapter.adapter=wordAdapter

        return generatedView
    }
}