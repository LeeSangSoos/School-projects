package edu.skku.cs.pa1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    var inputword : String=""
    var wordlist=ArrayList<String>()
    var answer : String=""
    var graylist=ArrayList<Char>()
    var yellowlist=ArrayList<Char>(5)
    var greenlist=ArrayList<Char>(5)
    var colorlist=arrayOf('r','r','r','r','r')
    var inputlist=arrayOf('r','r','r','r','r')
    var dics=ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputtext=findViewById<TextView>(R.id.input) //input text& submit button
        val submitBtn = findViewById<Button>(R.id.submit)

        val mainview = findViewById<ListView>(R.id.main_wordle) //main words view
        val greenview=findViewById<RecyclerView>(R.id.greenview) //green words
        val yellowview=findViewById<RecyclerView>(R.id.yellowview) //yellow words
        val grayview=findViewById<RecyclerView>(R.id.grayview) //gray words
        grayview.layoutManager=LinearLayoutManager(this)
        yellowview.layoutManager=LinearLayoutManager(this)
        greenview.layoutManager=LinearLayoutManager(this)
        val grayadapter=grayadapter(graylist)//gray view adapter
        val yellowadapter=yellowadapter(yellowlist)//yellow view adapter
        val greenadapter=greenadapter(greenlist)//green view adapter
        val myAdapter = main_adapter(wordlist, applicationContext, answer) //main view adapter
        mainview.adapter = myAdapter
        grayview.adapter = grayadapter
        yellowview.adapter = yellowadapter
        greenview.adapter = greenadapter

        val dic=assets.open("wordle_words.txt")
        val bufferedReader = BufferedReader(InputStreamReader(dic))
        var word: String?
        while (bufferedReader.readLine().also { word = it } != null) {//set answer
            dics.add(word?.trim().toString())
        }
        answer=dics[Random.nextInt(dics.size)]

        submitBtn.setOnClickListener{
            for(i in 0..4)
                inputlist[i]='r'

            inputword= inputtext.text.toString().lowercase()

            var check=0
            for(wordfrom in dics) {//set answer
                if(inputword==wordfrom){
                    check=1
                    wordlist.add(inputword)
                    val myAdapter = main_adapter(wordlist, applicationContext, answer) //main view adapter

                    for(i in 0..4){//check gray,yellow,green
                        for(j in 0..4){
                            if(inputword[i]==answer[j]&&colorlist[j]!='g'){
                                colorlist[j]='y'
                                inputlist[i]='y'
                            }
                        }
                        if(inputword[i]==answer[i]){
                            colorlist[i]='g'
                            inputlist[i]='g'
                        }
                    }

                    for(i in 0..4){
                        if(inputlist[i]=='r'){
                            if(inputword[i] in graylist)
                                continue
                            else{
                                if(inputword[i] in greenlist )
                                    continue
                                if(inputword[i] in yellowlist)
                                    continue
                                graylist.add(inputword[i])
                            }
                        }
                    }
                    for(i in 0..4){
                        if(colorlist[i]=='y'){
                            if(answer[i] in yellowlist)
                                continue
                            else{
                                if(answer[i] in greenlist)
                                    continue
                                else{
                                    if(answer[i] in graylist)
                                        graylist.remove(answer[i])
                                    yellowlist.add(answer[i])
                                }
                            }
                        }
                        else if(colorlist[i]=='g'){
                            if(answer[i] in greenlist)
                                continue
                            else{
                                if(answer[i] in yellowlist)
                                    yellowlist.remove(answer[i])
                                if(answer[i] in graylist)
                                    graylist.remove(answer[i])
                                greenlist.add(answer[i])
                            }
                        }
                    }

                    val grayadapter=grayadapter(graylist)//gray view adapter
                    val yellowadapter=yellowadapter(yellowlist)//yellow view adapter
                    val greenadapter=greenadapter(greenlist)//green view adapter
                    mainview.adapter = myAdapter
                    grayview.adapter = grayadapter
                    yellowview.adapter = yellowadapter
                    greenview.adapter = greenadapter
                    break;
                }
            }
            if(check==0)
                Toast.makeText(this,"Word '$inputword' not in dictionary!",Toast.LENGTH_SHORT).show()
        }
    }
}