package edu.skku.cs.pa1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListAdapter
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class word_adapter(val word: String, val answer: String) : RecyclerView.Adapter<word_adapter.ViewHolder>(){

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val chartext: TextView = itemView.findViewById(R.id.letter1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.main_letter, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val letter = word[position].toString()
        holder.chartext.setBackgroundColor(ContextCompat.getColor(holder.itemView.context, R.color.gray))
        holder.chartext.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.white))
        for(i in 0..4){
            if(word[position]==answer[i])
                holder.chartext.setBackgroundColor(ContextCompat.getColor(holder.itemView.context, R.color.yellow))
        }
        if(word[position]==answer[position]){
            holder.chartext.setBackgroundColor(ContextCompat.getColor(holder.itemView.context, R.color.green))
        }
        holder.chartext.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.black))
        holder.chartext.text = letter.uppercase()
    }

    override fun getItemCount(): Int {
        return word.length
    }

}