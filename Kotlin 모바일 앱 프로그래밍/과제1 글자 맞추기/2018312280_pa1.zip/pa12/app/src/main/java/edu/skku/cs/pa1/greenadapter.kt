package edu.skku.cs.pa1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class greenadapter (val word: ArrayList<Char>) : RecyclerView.Adapter<greenadapter.ViewHolder>(){

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val chartext: TextView = itemView.findViewById(R.id.letter1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.main_letter, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val letter = word[position].toString()
        holder.chartext.setBackgroundColor(ContextCompat.getColor(holder.itemView.context, R.color.green))
        holder.chartext.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.black))
        holder.chartext.text = letter.uppercase()
    }

    override fun getItemCount(): Int {
        return word.size
    }
}