#include <fstream>
#include <vector>
#include <iostream>
#include <algorithm>
#include <string>
#include <cmath>
using namespace std;

string divcode(const short ins, const int start, const int last);
void find(const short ins[32]);
string oz(short ins);
int imtde(string imm);
int bitde(short shortimm[32], int length);
int reftode(string imm);
int shmtode(string imm);
string bittohex(short* bit);
short* dectobit(int dec);
int bittodec(short bit[32]);
int N = 0;
int reg[32] = {};
int pc[32];

void hexdump(void* ptr, const int buflen)
{
    unsigned char* buf = (unsigned char*)ptr;
    int i, j, d, hex = 0;
    short ins[32] = { 0, };
    for (i = 0; i < N * 4; i += 4) {
        for (j = 0; j < 4; j += 4) {
            if (i + j < N * 4) {
                //cout << "inst " << (i + j) / 4 << ": ";
                for (int a = 0; a < 32; a += 8) {
                    d = buf[i + j + a / 8];
                    for (int k = 0; k < 8; k++) {
                        if (d % 2 != 0) {
                            ins[k + a] = 1;
                        }
                        else {
                            ins[k + a] = 0;
                        }
                        d = d / 2;
                    }
                }
                /*for (int i = 31; i >= 0; i -= 4) {
                    hex = hex + ins[i] * 8;
                    hex = hex + ins[i - 1] * 4;
                    hex = hex + ins[i - 2] * 2;
                    hex = hex + ins[i - 3] * 1;
                    if (hex == 10)
                        printf("a");
                    else if (hex == 11)
                        printf("b");
                    else if (hex == 12)
                        printf("c");
                    else if (hex == 13)
                        printf("d");
                    else if (hex == 14)
                        printf("e");
                    else if (hex == 15)
                        printf("f");
                    else
                        printf("%d", hex);
                    hex = 0;
                }*/
                find(ins);
                for (int i = 0; i < 32; i++) {
                    ins[i] = 0;
                }
                //printf("\n");
            }
        }
    }
}
int main(int argc, char* argv[])
{
    ifstream in;
    N = stoi(argv[2]);
    for (int i = 0; i < 32; i++) {
        reg[i] = 0;
    }
    for (int i = 0; i < 32; i++) {
        pc[i] = 0;
    }
    in.open(argv[1], ios::in | ios::binary);
    if (in.is_open())
    {
        streampos start = in.tellg();

        in.seekg(0, std::ios::end);

        streampos end = in.tellg();

        in.seekg(0, std::ios::beg);

        std::vector<char> contents;
        contents.resize(static_cast<size_t>(end - start));

        in.read(&contents[0], contents.size());

        hexdump(contents.data(), contents.size());

        if (contents.size() < N * 4) {
            cout << "No more instructions" << endl;
        }
    }

    for (int i = 0; i < 32; i++) {
        cout << "x" << i << ": 0x" << bittohex(dectobit(reg[i])) << endl;
    }
    cout << "PC: " << "0x" << bittohex(dectobit(pc[i])) << endl;
    /*for (int i = 0; i < 32; i++) {
        cout << "x" << i << ": 0x" << reg[i] << endl;
    }*/
    in.close();
    return 0;
}
string oz(short ins) {
    string oz;
    oz.clear();
    if (ins == 1)
        oz = "1";
    else
        oz = "0";
    return oz;
}
string divcode(const short ins[32], const int start, const int last) {
    string str;
    str.clear();
    for (int i = start; i >= last; i--) {
        str.append(oz(ins[i]));
    }
    return str;
}
int bitode(short shortimm[100], int length) {
    int dec = 0;
    for (int i = 0; i < length; i++) {
        dec += shortimm[i] * pow(2, length - 1 - i);
    }
    return dec;
}
int imtode(string imm) {
    int deim;
    short shortimm[100];
    int length = 0;
    for (int i = 0; i < 100; i++) {
        if (imm[i] == '\0') {
            length = i;
            break;
        }
    }
    if (imm[0] == '0') {
        for (int i = 1; i < length; i++) {
            if (imm[i] == '1')
                shortimm[i - 1] = 1;
            else if (imm[i] == '0')
                shortimm[i - 1] = 0;
        }
        deim = bitode(shortimm, length - 1);
    }
    if (imm[0] == '1') {
        for (int i = 1; i < length; i++) {
            if (imm[i] == '1')
                shortimm[i - 1] = 0;
            else if (imm[i] == '0')
                shortimm[i - 1] = 1;
        }
        deim = bitode(shortimm, length - 1);
        deim += 1;
        deim = deim * (-1);
    }
    return deim;
}
int reftode(string imm) {
    int deim;
    short shortimm[32];
    int length = 0;
    for (int i = 0; i < 32; i++) {
        if (imm[i] == '\0') {
            length = i;
            break;
        }
    }
    for (int i = 0; i < length; i++) {
        if (imm[i] == '1')
            shortimm[i] = 1;
        else if (imm[i] == '0')
            shortimm[i] = 0;
    }
    deim = bitode(shortimm, length);
    return deim;
}
int shmtode(string imm) {
    int deim;
    short shortimm[32];
    int length = 0;
    for (int i = 0; i < 32; i++) {
        if (imm[i] == '\0') {
            length = i;
            break;
        }
    }
    for (int i = 0; i < length; i++) {
        if (imm[i] == '1')
            shortimm[i] = 1;
        else if (imm[i] == '0')
            shortimm[i] = 0;
    }
    deim = bitode(shortimm, length);
    return deim;
}
string bittohex(short* bit) {
    string hex;
    hex.clear();
    int tmp = 0;
    for (int i = 0; i < 32; i += 4) {
        for (int j = 0; j < 4; j++) {
            tmp += bit[j + i] * pow(2, 3 - j);
        }
        if (tmp == 10)
            hex += "a";
        else if (tmp == 11)
            hex += "b";
        else if (tmp == 12)
            hex += "c";
        else if (tmp == 13)
            hex += "d";
        else if (tmp == 14)
            hex += "e";
        else if (tmp == 15)
            hex += "f";
        else
            hex += to_string(tmp);
        tmp = 0;
    }
    return hex;
}
short* dectobit(int dec) {
    short* bits = new short[32];
    if (dec >= 0) {
        for (int i = 31; i >= 0; i--) {
            bits[i] = dec % 2;
            dec = dec / 2;
        }
    }
    else {
        for (int i = 31; i >= 0; i--) {
            bits[i] = dec % 2;
            dec = dec / 2;
        }
        for (int i = 31; i >= 0; i--) {
            if (bits[i] == 0)
                bits[i] = 1;
            else
                bits[i] = 0;
        }
        bits[31] += 1;
        for (int i = 31; i >= 0; i--) {
            if (bits[i] == 2) {
                bits[i] = 0;
                if (i - 1 >= 0)
                    bits[i - 1] += 1;
                else {
                    bits[i] = 0;
                }
            }
        }
    }
    return bits;
}
int bittodec(short bit[32]) {
    int dec = 0;
    if (bit[0] == 1) {
        for (int i = 31; i >= 0; i--) {
            if (bit[i] == 0)
                bit[i] = 1;
            else
                bit[i] = 0;
        }
        bit[31] += 1;
        for (int i = 31; i >= 0; i--) {
            if (bit[i] == 2) {
                bit[i] = 0;
                if (i - 1 >= 0)
                    bit[i - 1] += 1;
                else {
                    bit[i] = 0;
                }
            }
        }
        for (int i = 31; i >= 0; i--) {
            dec += bit[i] * pow(2, 31 - i);
        }
        dec *= -1;
    }
    else {
        for (int i = 31; i >= 0; i--) {
            dec += bit[i] * pow(2, 31 - i);
        }
    }
    return dec;
}
void find(const short ins[32]) {
    string imm, funct7, rs2, rs1, funct3,
        rd, op, shamt, inst;
    imm.clear(); funct7.clear(); rs2.clear(); rs1.clear(); funct3.clear();
    rd.clear(); op.clear(); shamt.clear();
    int rd1, rt1, rt2, im;

    op = divcode(ins, 6, 0);
    if (op == "0110111") {
        rd = divcode(ins, 11, 7);
        imm = divcode(ins, 31, 12);
        imm.append("000000000000");
        rd1 = reftode(rd);
        im = imtode(imm);
        inst = "lui";
        reg[rd1] = im;
    }
    else if (op == "0010111") {
        rd = divcode(ins, 11, 7);
        imm = divcode(ins, 31, 12);
        imm.append("000000000000");
        //p1 = reftode(rd);
        //p2 = imtode(imm);
        inst = "auipc";
    }
    else if (op == "1101111") {
        rd = divcode(ins, 11, 7);
        imm.append(oz(ins[31]));
        imm.append(divcode(ins, 19, 12));
        imm.append(oz(ins[20]));
        imm.append(divcode(ins, 30, 21));
        imm.append("0");

        //p1 = reftode(rd);
        //p2 = imtode(imm);
        inst = "jal";
    }
    else if (op == "1100111") {
        rd = divcode(ins, 11, 7);
        funct3 = divcode(ins, 14, 12);
        rs1 = divcode(ins, 19, 15);
        imm = divcode(ins, 31, 20);

        //p1 = reftode(rd);
        //p2 = imtode(imm);
        //p2 += "("; p2 += reftode(rs1); p2 += ")";
        inst = "jalr";
    }
    else if (op == "1100011") {
        funct3 = divcode(ins, 14, 12);
        imm.append(oz(ins[31]));
        imm.append(oz(ins[7]));
        imm.append(divcode(ins, 30, 25));
        imm.append(divcode(ins, 11, 8));
        imm.append("0");
        rs1 = divcode(ins, 19, 15);
        rs2 = divcode(ins, 24, 20);
        if (funct3 == "000")
            inst = "beq";
        else if (funct3 == "001")
            inst = "bne";
        else if (funct3 == "100")
            inst = "blt";
        else if (funct3 == "101")
            inst = "bge";
        else if (funct3 == "110")
            inst = "bltu";
        else if (funct3 == "111")
            inst = "bgeu";
        //p1 = reftode(rs1);
        //p2 = reftode(rs2);
        //p3 = imtode(imm);
    }
    else if (op == "0000011") {
        funct3 = divcode(ins, 14, 12);
        rd = divcode(ins, 11, 7);
        rs1 = divcode(ins, 19, 15);
        imm = divcode(ins, 31, 20);
        if (funct3 == "000")
            inst = "lb";
        else if (funct3 == "001")
            inst = "lh";
        else if (funct3 == "010")
            inst = "lw";
        else if (funct3 == "100")
            inst = "lbu";
        else if (funct3 == "101")
            inst = "lhu";
        //p1 = reftode(rd);
        //p2 = imtode(imm);
        //p2 += "("; p2 += reftode(rs1); p2 += ")";
    }
    else if (op == "0100011") {
        funct3 = divcode(ins, 14, 12);
        rs1 = divcode(ins, 19, 15);
        rs2 = divcode(ins, 24, 20);
        imm.append(divcode(ins, 31, 25));
        imm.append(divcode(ins, 11, 7));
        if (funct3 == "000")
            inst = "sb";
        else if (funct3 == "001")
            inst = "sh";
        else if (funct3 == "010")
            inst = "sw";
        //p1 = reftode(rs2);
        //p2 = imtode(imm);
        //p2 += "("; p2 += reftode(rs1); p2 += ")";
    }
    else if (op == "0010011") {
        funct3 = divcode(ins, 14, 12);
        rd = divcode(ins, 11, 7);
        rs1 = divcode(ins, 19, 15);
        if (funct3 == "000") {
            imm = divcode(ins, 31, 20);
            rd1 = reftode(rd);
            rt1 = reftode(rs1);
            im = imtode(imm);
            inst = "addi";
            reg[rd1] = reg[rt1] + im;
        }
        else if (funct3 == "010") {
            imm = divcode(ins, 31, 20);
            rd1 = reftode(rd);
            rt1 = reftode(rs1);
            im = imtode(imm);
            inst = "slti";
            if (reg[rt1] < im)
                reg[rd1] = 1;
            else
                reg[rd1] = 0;
        }
        else if (funct3 == "011") {
            imm = divcode(ins, 31, 20);
            rd1 = reftode(rd);
            rt1 = reftode(rs1);
            im = imtode(imm);
            inst = "sltiu";
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* brt2 = new short[32];
            brt2 = dectobit(im);
            for (int i = 0; i < 32; i++) {
                if (brt1[i] < brt2[i])
                    reg[rd1] = 1;
            }
            if (reg[rd1] != 1) {
                reg[rd1] = 0;
            }
        }
        else if (funct3 == "100") {
            imm = divcode(ins, 31, 20);
            rd1 = reftode(rd);
            rt1 = reftode(rs1);
            im = imtode(imm);
            inst = "xori";
            short brd[32] = { 0, };
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* bim = new short[32];
            bim = dectobit(im);
            for (int i = 0; i < 32; i++) {
                if (brt1[i] != bim[i])
                    brd[i] = 1;
                else
                    brd[i] = 0;
            }
            reg[rd1] = bittodec(brd);
        }
        else if (funct3 == "110") {
            imm = divcode(ins, 31, 20);
            rd1 = reftode(rd);
            rt1 = reftode(rs1);
            im = imtode(imm);
            inst = "ori";
            short brd[32] = { 0, };
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* bim = new short[32];
            bim = dectobit(im);
            for (int i = 0; i < 32; i++) {
                if (brt1[i] == 1 || bim[i] == 1)
                    brd[i] = 1;
                else
                    brd[i] = 0;
            }
            reg[rd1] = bittodec(brd);
        }
        else if (funct3 == "111") {
            imm = divcode(ins, 31, 20);
            rd1 = reftode(rd);
            rt1 = reftode(rs1);
            im = imtode(imm);
            inst = "andi";
            short brd[32] = { 0, };
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* bim = new short[32];
            bim = dectobit(im);
            for (int i = 0; i < 32; i++) {
                if (brt1[i] == 1 && bim[i] == 1)
                    brd[i] = 1;
                else
                    brd[i] = 0;
            }
            reg[rd1] = bittodec(brd);
        }
        else if (funct3 == "001") {
            funct7 = divcode(ins, 31, 25);
            shamt = divcode(ins, 24, 20);
            rd1 = reftode(rd);
            rt1 = reftode(rs1);
            rt2 = shmtode(shamt);
            inst = "slli";
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* brt2 = new short[32];
            brt2 = dectobit(rt2);
            int shmt = 0;
            for (int i = 31; i >= 27; i--) {
                shmt += brt2[i] * pow(2, 31 - i);
            }
            for (int i = 0; i < 32; i++) {
                if (i - shmt >= 0) {
                    brt1[i - shmt] = brt1[i];
                }
                if (i + shmt < 32)
                    brt1[i] = brt1[i + shmt];
                else
                    brt1[i] = 0;
            }
            reg[rd1] = bittodec(brt1);
        }
        else if (funct3 == "101") {
            funct7 = divcode(ins, 31, 25);
            shamt = divcode(ins, 24, 20);
            rd1 = reftode(rd);
            rt1 = reftode(rs1);
            rt2 = shmtode(shamt);
            if (funct7 == "0000000") {
                inst = "srli";
                short* brt1 = new short[32];
                brt1 = dectobit(reg[rt1]);
                short* brt2 = new short[32];
                brt2 = dectobit(rt2);
                int shmt = 0;
                for (int i = 31; i >= 27; i--) {
                    shmt += brt2[i] * pow(2, 31 - i);
                }
                for (int i = 31; i >= 0; i--) {
                    if (i + shmt < 32) {
                        brt1[i + shmt] = brt1[i];
                    }
                    if (i - shmt >= 0)
                        brt1[i] = brt1[i - shmt];
                    else
                        brt1[i] = 0;
                }
                reg[rd1] = bittodec(brt1);
            }

            else if (funct7 == "0100000") {
                inst = "srai";
                short* brt1 = new short[32];
                brt1 = dectobit(reg[rt1]);
                short* brt2 = new short[32];
                brt2 = dectobit(rt2);
                bool cal = false;
                int shmt = 0;
                for (int i = 31; i >= 27; i--) {
                    shmt += brt2[i] * pow(2, 31 - i);
                }
                if (brt1[0] == 1)
                    cal = true;
                for (int i = 31; i >= 0; i--) {
                    if (i + shmt < 32) {
                        brt1[i + shmt] = brt1[i];
                    }
                    if (i - shmt >= 0)
                        brt1[i] = brt1[i - shmt];
                    else {
                        if (cal)brt1[i] = 1;
                        else brt1[i] = 0;
                    }
                }
                reg[rd1] = bittodec(brt1);
            }
        }
    }
    else if (op == "0110011") {
        rd = divcode(ins, 11, 7);
        funct3 = divcode(ins, 14, 12);
        rs1 = divcode(ins, 19, 15);
        rs2 = divcode(ins, 24, 20);
        funct7 = divcode(ins, 31, 25);
        rd1 = reftode(rd);
        rt1 = reftode(rs1);
        rt2 = reftode(rs2);
        if (funct3 == "000") {
            if (funct7 == "0000000") {
                inst = "add";
                reg[rd1] = reg[rt1] + reg[rt2];
            }
            else if (funct7 == "0100000") {
                inst = "sub";
                reg[rd1] = reg[rt1] - reg[rt2];
            }

        }
        else if (funct3 == "001") {
            inst = "sll";
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* brt2 = new short[32];
            brt2 = dectobit(reg[rt2]);
            int shmt = 0;
            for (int i = 31; i >= 27; i--) {
                shmt += brt2[i] * pow(2, 31 - i);
            }
            for (int i = 0; i < 32; i++) {
                if (i - shmt >= 0) {
                    brt1[i - shmt] = brt1[i];
                }
                if (i + shmt < 32)
                    brt1[i] = brt1[i + shmt];
                else
                    brt1[i] = 0;
            }
            reg[rd1] = bittodec(brt1);
        }
        else if (funct3 == "010") {
            inst = "slt";
            if (reg[rt1] < reg[rt2]) {
                reg[rd1] = 1;
            }
            else
                reg[rd1] = 0;
        }
        else if (funct3 == "011") {
            inst = "sltu";
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* brt2 = new short[32];
            brt2 = dectobit(reg[rt2]);
            for (int i = 0; i < 32; i++) {
                if (brt1[i] < brt2[i])
                    reg[rd1] = 1;
            }
            if (reg[rd1] != 1) {
                reg[rd1] = 0;
            }
        }
        else if (funct3 == "100") {
            inst = "xor";
            short brd[32] = { 0, };
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* brt2 = new short[32];
            brt2 = dectobit(reg[rt2]);
            for (int i = 0; i < 32; i++) {
                if (brt1[i] != brt2[i])
                    brd[i] = 1;
                else
                    brd[i] = 0;
            }
            reg[rd1] = bittodec(brd);
        }
        else if (funct3 == "101") {
            if (funct7 == "0000000") {
                inst = "srl";
                short* brt1 = new short[32];
                brt1 = dectobit(reg[rt1]);
                short* brt2 = new short[32];
                brt2 = dectobit(reg[rt2]);
                int shmt = 0;
                for (int i = 31; i >= 27; i--) {
                    shmt += brt2[i] * pow(2, 31 - i);
                }
                for (int i = 31; i >= 0; i--) {
                    if (i + shmt < 32) {
                        brt1[i + shmt] = brt1[i];
                    }
                    if (i - shmt >= 0)
                        brt1[i] = brt1[i - shmt];
                    else
                        brt1[i] = 0;
                }
                reg[rd1] = bittodec(brt1);
            }
            else if (funct7 == "0100000") {
                inst = "sra";
                short* brt1 = new short[32];
                brt1 = dectobit(reg[rt1]);
                short* brt2 = new short[32];
                brt2 = dectobit(reg[rt2]);
                int shmt = 0;
                bool cal = false;
                for (int i = 31; i >= 27; i--) {
                    shmt += brt2[i] * pow(2, 31 - i);
                }
                for (int i = 0; i < 32; i++) {
                    if (brt1[i] == 1) {
                        cal = true;
                        break;
                    }
                }
                if (brt1[0] == 1)
                    cal = true;
                for (int i = 31; i >= 0; i--) {
                    if (i + shmt < 32) {
                        brt1[i + shmt] = brt1[i];
                    }
                    if (i - shmt >= 0)
                        brt1[i] = brt1[i - shmt];
                    else {
                        if (cal)brt1[i] = 1;
                        else brt1[i] = 0;
                    }
                }
                reg[rd1] = bittodec(brt1);
            }

        }
        else if (funct3 == "110") {
            inst = "or";
            short brd[32] = { 0, };
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* brt2 = new short[32];
            brt2 = dectobit(reg[rt2]);
            for (int i = 0; i < 32; i++) {
                if (brt1[i] == 1 || brt2[i] == 1)
                    brd[i] = 1;
                else
                    brd[i] = 0;
            }
            reg[rd1] = bittodec(brd);
        }
        else if (funct3 == "111") {
            inst = "and";
            short brd[32] = { 0, };
            short* brt1 = new short[32];
            brt1 = dectobit(reg[rt1]);
            short* brt2 = new short[32];
            brt2 = dectobit(reg[rt2]);
            for (int i = 0; i < 32; i++) {
                if (brt1[i] == 1 && brt2[i] == 1)
                    brd[i] = 1;
                else
                    brd[i] = 0;
            }
            reg[rd1] = bittodec(brd);
        }
    }
    //cout << " " << inst;
    /*
     if (inst.compare("unknown instruction")!=0) {
        if (p1 != "n") {
            cout << " " << p1;
            if (p2 != "n") {
                cout << ", " << p2;
                if (p3 != "n") {
                    cout << ", " << p3;
                }
            }
        }
     }
     */
    if (rd1 == 0) {
        reg[rd1] = 0;
    }
}